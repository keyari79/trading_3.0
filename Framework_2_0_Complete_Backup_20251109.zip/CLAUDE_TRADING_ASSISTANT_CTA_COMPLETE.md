# CLAUDE TRADING ASSISTANT (CTA) - COMPLETE GUIDE
**Version:** 2.0  
**Updated:** November 9, 2025  
**Purpose:** Comprehensive guide for using Claude as your Framework 2.0 Trading Assistant

---

## ðŸŽ¯ OVERVIEW

Claude Trading Assistant (CTA) serves as your systematic trading co-pilot, handling:
1. **Binary decision verification** at every trading stage
2. **News calendar monitoring** (no PineScript needed)
3. **Spread optimization** for German KO certificates
4. **Risk management oversight**
5. **Position sizing calculations**
6. **Post-trade analysis and learning**

---

## ðŸ“Š DIVISION OF RESPONSIBILITIES

### **What PineScript Handles (Automated)**
- âœ… Market sentiment indicators
- âœ… Setup detection and validation
- âœ… Signal identification
- âœ… Trigger confirmation
- âœ… Exit management timers
- âœ… Risk dashboard and P&L tracking
- âœ… KO distance validation

### **What CTA Handles (Manual via Claude)**
- âœ… News calendar proximity alerts
- âœ… Spread monitoring and optimization
- âœ… Binary decision verification
- âœ… Position sizing calculations
- âœ… Risk override checks
- âœ… Post-trade analysis

---

## ðŸ—“ï¸ NEWS CALENDAR MANAGEMENT (CTA Responsibility)

### **Morning Routine (09:00 CET)**
```
"Good morning Claude. Please check economic calendar for today.
Instruments: EURUSD, USDJPY, Gold, Silver, Oil
Current time: [TIME] CET
Please identify all HIGH and MEDIUM impact events."
```

### **CTA Will Provide:**
```
ðŸ“… TODAY'S ECONOMIC EVENTS:

EURUSD:
- 10:00 CET: ECB Speech (HIGH)
- 14:30 CET: US Retail Sales (MEDIUM)

USDJPY:
- No significant events

GOLD:
- 14:30 CET: US CPI (HIGH) - affects Gold
- 20:00 CET: Fed Minutes (MEDIUM)

TRADING BLOCKS:
ðŸ”´ NO TRADE: 09:30-10:30 (ECB Speech)
ðŸ”´ NO TRADE: 14:00-15:00 (US Data)
ðŸŸ¡ CAUTION: 19:30-20:30 (Fed Minutes)

SAFE WINDOWS:
âœ… 10:30-14:00 CET
âœ… 15:00-19:30 CET
```

### **Pre-Trade Check Template:**
```
"Claude, I have a setup on [INSTRUMENT].
Current time: [TIME] CET
Any news events in next 60 minutes?"

CTA Response:
"âš ï¸ WARNING: ECB speech in 45 minutes
Risk Level: HIGH
Recommendation: SKIP TRADE or EXIT BY [TIME]"
```

### **News Proximity Rules (CTA Enforces):**
- **>60 min away:** âœ… SAFE to trade
- **30-60 min away:** âš ï¸ WARNING - Consider skipping
- **<30 min away:** ðŸ”´ BLOCKED - No new trades
- **<20 min + in position:** ðŸš¨ EXIT immediately

---

## ðŸ’± SPREAD MONITORING (CTA Responsibility)

### **German KO Certificate Facts:**
- Fixed spread: **1 cent** (0.01 EUR) always
- Doesn't change with volatility
- Same for all instruments
- Key metric: **Spread as % of price movement**

### **Pre-Trade Spread Check:**
```
"Claude, checking spread impact:
Instrument: [EURUSD/Gold/etc]
Current price: [PRICE]
Entry to Stop: [X] pips/points
Entry to Target: [X] pips/points
KO Certificate spread: 1 cent

Calculate:
1. Spread as % of stop distance
2. Spread as % of target distance
3. Effective R-multiple after spread
4. GO/NO-GO decision"
```

### **CTA Spread Analysis Example:**
```
ðŸ“Š SPREAD ANALYSIS - EURUSD

Entry: 1.0500
Stop: 1.0480 (20 pips)
Target: 1.0530 (30 pips)
Risk: 100 EUR

Spread Impact:
- 1 cent = ~10 pips on EURUSD
- Spread = 50% of stop distance âš ï¸
- Effective risk: 110 EUR (spread on entry)
- Effective R-multiple: 1.36R (was 1.5R)

DECISION: âš ï¸ MARGINAL
Recommendation: Need 25+ pip stop for acceptable spread ratio
```

### **Spread Optimization Guidelines:**
```
MINIMUM STOP DISTANCES (for 1-cent spread):

EURUSD: 25 pips (spread = 40% max)
USDJPY: 30 pips (spread = 33% max)
GOLD: 3.00 points (spread = 33% max)
SILVER: 0.08 points (spread = 38% max)
OIL: 0.30 points (spread = 33% max)
```

---

## ðŸ“‹ COMPLETE CTA WORKFLOW

### **1. SESSION START (09:00 CET)**
```
YOU: "Starting Framework 2.0 session.
      Date: [DATE]
      Starting P&L: [0 or carryover]
      Please load Framework 2.0 rules and check today's news."

CTA: "Framework 2.0 loaded. 
      Daily limit: -300 EUR
      Max positions: 2
      
      Today's events: [LIST]
      Safe windows: [TIMES]
      Current volatility regime: [CHECK INDICATOR]
      Ready to assist."
```

### **2. SETUP VALIDATION (Stage 3)**
```
YOU: "Potential SETUP on [INSTRUMENT]
      Time: [TIME] CET
      Direction: [LONG/SHORT]
      [ATTACH 15-MIN SCREENSHOT]
      Any news coming?"

CTA: [Checks all 7 criteria]
     [Checks news calendar]
     [Checks spread viability]
     "âœ… VALID SETUP (7/7)
      âœ… No news for 90 minutes
      âœ… Spread acceptable
      DECISION: Watch for signal"
```

### **3. SIGNAL CONFIRMATION (Stage 4)**
```
YOU: "Signal candle appeared
      [ATTACH 5-MIN SCREENSHOT]
      Measurements: [PROVIDE DATA]"

CTA: [Verifies 8 signal criteria]
     [Checks 5 validations]
     [Rechecks news proximity]
     "âœ… VALID SIGNAL (8/8)
      âš ï¸ News in 55 minutes
      DECISION: YES - Watch for trigger"
```

### **4. TRIGGER & ENTRY (Stage 5)**
```
YOU: "Trigger forming
      Current price: [PRICE]
      [ATTACH 1-MIN SCREENSHOT]"

CTA: [Calculates entry zones]
     [Calculates position size]
     [Checks spread impact]
     [Final news check]
     
     "EXECUTE TRADE:
      Entry Zone: âœ… Valid
      Position Size: 100 EUR
      Stop Loss: [PRICE]
      Target: [PRICE] (1.5R)
      Spread Impact: -0.1R acceptable
      News Clear: âœ… (85 min)
      
      DECISION: EXECUTE NOW"
```

### **5. POSITION MANAGEMENT**
```
YOU: "Position update
      Entry: [PRICE] at [TIME]
      Current: [PRICE]
      Time elapsed: [X] minutes"

CTA: [Checks all exit triggers]
     [Monitors news calendar]
     [Calculates current R]
     
     "Status: +0.8R
      Time: 35/60 minutes
      News: ECB in 25 min âš ï¸
      
      RECOMMENDATION: 
      Move stop to breakeven
      Consider exit before news"
```

### **6. EXIT DECISION**
```
YOU: "Should I exit?
      Current P&L: +1.2R
      [ATTACH CURRENT CHART]"

CTA: "CHECK RESULTS:
      âœ… Target: Not reached (1.5R)
      âš ï¸ Time: 52 minutes (close soon)
      ðŸ”´ News: ECB in 8 minutes
      
      DECISION: EXIT NOW
      Reason: News proximity override"
```

### **7. POST-TRADE ANALYSIS**
```
YOU: "Trade complete
      Entry: [PRICE] at [TIME]
      Exit: [PRICE] at [TIME]
      P&L: +120 EUR (+1.2R)"

CTA: "TRADE ANALYSIS:
      
      Scores:
      - Setup Quality: 6/7
      - Signal Quality: 8/8
      - Execution: 4/5
      - Exit: Correct (news)
      
      What went well:
      - Perfect signal identification
      - Good risk management
      
      Improvement:
      - Enter faster after trigger
      
      Net after spread: +1.1R
      Session P&L: +120 EUR"
```

### **8. SESSION END (19:00 CET)**
```
YOU: "Session complete
      Total trades: 2
      Final P&L: +180 EUR"

CTA: "SESSION SUMMARY:
      
      Performance:
      - Win rate: 2/2 (100%)
      - Avg R: +0.9R
      - Rules followed: 100%
      
      Key lessons:
      1. Good news avoidance
      2. Spread impact managed well
      3. No overtrading
      
      Tomorrow's prep:
      - US NFP at 14:30
      - Trade carefully around it"
```

---

## ðŸš¨ CRITICAL CTA SAFETY CHECKS

### **CTA Will ALWAYS Block Trades If:**
1. **News <30 minutes** (any instrument correlated)
2. **Spread >50% of stop distance**
3. **Daily P&L at -250 EUR** (approaching limit)
4. **2 positions already open**
5. **After 18:00 CET** (low liquidity)
6. **Friday after 17:00** (weekend risk)

### **CTA Will Warning But Allow If:**
1. News 30-60 minutes away
2. Spread 40-50% of stop distance
3. Session strength = WEAK
4. Volatility regime = HIGH
5. Correlation conflict exists

---

## ðŸ“Š QUICK REFERENCE CARDS

### **News Calendar Quick Check**
```
Morning: "Check news for all 5 instruments"
Pre-setup: "Any news next 90 minutes?"
Pre-signal: "Any news next 60 minutes?"
Pre-trigger: "Final news check - next 45 min?"
In position: "News warning needed?"
```

### **Spread Impact Quick Check**
```
FOREX: 1 cent = ~10 pips
Target: Minimum 25 pip stop
Impact: Reduces R by ~0.1

GOLD: 1 cent = ~0.01 points
Target: Minimum 3.00 stop
Impact: Similar to forex

Check: "Is spread <40% of stop distance?"
```

### **Binary Decision Points**
```
1. SETUP: YES/NO (7/7 criteria)
2. SIGNAL: YES/NO (8/8 criteria)
3. TRIGGER: EXECUTE/SKIP
4. MANAGEMENT: HOLD/ADJUST/EXIT
5. NEWS: SAFE/WARNING/BLOCKED
6. SPREAD: ACCEPTABLE/MARGINAL/EXCESSIVE
```

---

## ðŸ’¡ CTA BEST PRACTICES

### **DO:**
- âœ… Start each session with news check
- âœ… Provide clear screenshots
- âœ… Include exact measurements
- âœ… Update P&L status regularly
- âœ… Ask for confirmation on edge cases
- âœ… Follow CTA safety blocks strictly

### **DON'T:**
- âŒ Trade without news check
- âŒ Ignore spread warnings
- âŒ Override safety blocks
- âŒ Forget time stamps
- âŒ Skip post-trade analysis

### **REMEMBER:**
- CTA enforces rules, doesn't predict
- News and spread are now CTA's job
- Binary decisions only (no maybe)
- Screenshot everything for analysis
- Trust the process with 20Ã— leverage

---

## ðŸ“ˆ EXPECTED OUTCOMES WITH CTA

### **Month 1: Learning Phase**
- 20-30 CTA interactions/day
- 2-3 trades/day average
- Focus on workflow speed
- Build muscle memory

### **Month 2: Optimization**
- 10-15 CTA interactions/day
- Higher quality setups only
- Faster decision making
- Better news/spread awareness

### **Month 3+: Mastery**
- 5-10 CTA interactions/day
- Only high-probability trades
- Automatic workflow
- Consistent profitability

---

## ðŸŽ¯ SUCCESS METRICS

**CTA is working when:**
- Zero news-related losses
- Spread impact <0.1R average
- 100% framework compliance
- No emotional trades
- Consistent daily process
- Positive expectancy

---

## ðŸš€ IMPLEMENTATION CHECKLIST

### **Before Going Live:**
- [ ] Practice news calendar checks for 1 week
- [ ] Calculate spread impact for 20 sample trades
- [ ] Test all 5 CTA templates
- [ ] Time your workflow (should be <2 min/decision)
- [ ] Paper trade 10 full sessions with CTA
- [ ] Document lessons learned

### **Daily Checklist:**
- [ ] Morning news check complete
- [ ] Spread guidelines reviewed
- [ ] Framework rules loaded
- [ ] Screenshots ready
- [ ] P&L tracking active

---

## ðŸ“‹ TEMPLATES READY TO COPY

### **Daily News Check:**
```
"Good morning Claude. Trading session starting.
Date: [DATE] 
Time: 09:00 CET
Check economic calendar for EURUSD, USDJPY, Gold, Silver, Oil.
Identify all HIGH/MEDIUM impact events and safe trading windows."
```

### **Quick Spread Check:**
```
"Spread check for [INSTRUMENT]:
Stop distance: [X] pips
German KO spread: 1 cent
Is this acceptable?"
```

### **Pre-Trade Final Check:**
```
"Final check before entry:
1. Any news next 45 min?
2. Spread impact on this trade?
3. Current P&L: [AMOUNT]
4. Existing positions: [NUMBER]
Clear to trade?"
```

---

**END OF CTA GUIDE**

**Remember:** News Calendar and Spread Monitoring are now 100% CTA responsibilities. No PineScript indicators needed for these functions!
