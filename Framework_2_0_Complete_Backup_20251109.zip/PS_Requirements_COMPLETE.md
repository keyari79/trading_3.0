# PS_REQUIREMENTS - COMPLETE
**Framework 2.0 PineScript Requirements Document**

**Version:** 2.0 (Merged Complete)  
**Date:** November 7, 2025  
**Total Indicators:** 19

---

## PRIORITY CLASSIFICATION

### **MUST-HAVE (CRITICAL) - 8 Indicators**
1. Risk Management Dashboard (#14)
2. KO Distance Validator (#18)
3. News Calendar Proximity Alert (#16)
4. Volatility Regime Monitor (#2)
5. SETUP Metrics Validator (#6)
6. SIGNAL Decision Panel (#8)
7. Trigger Master Detection (#11)
8. Spread Monitor (#17)

### **SHOULD-HAVE (IMPORTANT) - 6 Indicators**
9. Market Environment Monitor (#1)
10. Exit Management Dashboard (#13)
11. Volume Monitors (#9 & #12)
12. Correlation Matrix (#3)
13. Multi-Timeframe Sync Monitor (#19)
14. Position Size Calculator (#15)

### **NICE-TO-HAVE (ENHANCEMENT) - 5 Indicators**
15. Session Tracker (#4 & #10)
16. Multi-Instrument Screener (#5)
17. Quality Tier Display (#7)

---

## STAGE 1: MARKET SENTIMENT (Screening Phase)

### **INDICATOR #1: Market Environment & Conviction Monitor**
**Priority:** SHOULD-HAVE  
**Timeframe:** Any/Multi-timeframe  
**Location:** Separate panel or top of chart

#### Requirements:

**A. VIX Classification System**
- Fetch real-time VIX data
- Classify into 5 zones:
  - CALM: <15
  - NORMAL: 15-20
  - ELEVATED: 20-25
  - RISK-OFF: 25-30
  - PANIC: >30
- Display position sizing recommendations based on VIX
- Visual color coding (green/yellow/orange/red)

**B. Currency Strength Rankings**
- Calculate 24-hour % change for 8 major currencies (USD, EUR, GBP, JPY, CHF, AUD, NZD, CAD)
- Rank from 1 (strongest) to 8 (weakest)
- Update every 15 minutes
- Display with color coding

**C. Top 3 Pair Opportunities**
- Auto-generate based on rankings
- Display conviction levels (HIGH/MEDIUM/LOW)
- Format: "GBPJPY (HIGH) - Buy GBP #1 vs JPY #8"

**D. Commodity Context Display**
- Show Gold, Oil, Silver, Copper performance
- Display correlation indicators

---

### **INDICATOR #2: Volatility Regime Detector**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** Daily & 4H  
**Location:** Separate panel below main chart

#### Requirements:

**A. ATR Percentile Calculation**
- Calculate ATR(14) on current timeframe
- Compare to 100-day historical ATR values
- Calculate percentile rank (0-100)
- Update on bar close

**B. Regime Classification**
Based on percentile:
- LOW: <P20 (yellow background)
- NORMAL: P20-P80 (green background)
- HIGH: >P80 (red background)

**C. Auto Position Size Display**
- LOW: "100 EUR / Target 1.3R / Stop 0.8Ã— ATR"
- NORMAL: "100 EUR / Target 1.5-2.0R / Stop 1.0Ã— ATR"
- HIGH: "50 EUR / Target 1.5-2.0R / Stop 1.5Ã— ATR"

**D. Entry Zone Adjustment Display**
- LOW/NORMAL: "Entry Zone: Â±0.5 ATR"
- HIGH: "Entry Zone: Â±0.75 ATR"
- Show actual pip values

**E. Multi-Instrument Panel**
- Show regime for user-selected instruments (5 max)
- Format: "EUR/USD: N | USD/JPY: L | Gold: H"
- Update every 5 minutes
- Alert on regime changes

**F. Both Daily & 4H Regimes**
- Calculate separately for Daily and 4H
- Display both: "Daily: N | 4H: L"

---

### **INDICATOR #3: Correlation Matrix**
**Priority:** SHOULD-HAVE  
**Timeframe:** Daily (20-day rolling window)  
**Location:** Separate panel or table

#### Requirements:

**A. Correlation Calculations**
Calculate 20-day rolling correlation for:
- EUR/USD â†” USD/JPY
- EUR/USD â†” Gold
- Oil â†” USD/JPY
- Any user-defined pairs (up to 5 total)

**B. Conflict Detection Logic**
- Threshold: |correlation| â‰¥ 0.5
- Check position directions
- Flag conflicts in red

**C. Position Size Adjustment**
- Normal: "100 EUR both positions"
- Conflict: "50 EUR both positions"

**D. Visual Matrix**
Color-coded cells:
- Green: |correlation| < 0.4
- Yellow: 0.4 â‰¤ |correlation| < 0.5
- Red: |correlation| â‰¥ 0.5

**E. Update Frequency**
- Recalculate every 15 minutes
- Alert when correlation crosses 0.5 threshold

---

### **INDICATOR #4: Session Strength Assessment**
**Priority:** NICE-TO-HAVE  
**Timeframe:** Intraday (real-time)  
**Location:** Top banner or status bar

#### Requirements:

**A. Session Classification**
Three tiers: PRIME / ACCEPTABLE / WEAK

**B. Position Sizing Display**
- PRIME: "100 EUR"
- ACCEPTABLE: "75 EUR"
- WEAK: "50 EUR"

**C. Session Time Tracking**
- Asia: 00:00-07:00 UTC
- Europe: 07:00-12:00 UTC
- US: 12:00-20:00 UTC

**D. DST Adjustment**
- Auto-adjust for Daylight Saving Time
- Support CET/CEST timezone

---

## STAGE 2: SCREENING

### **INDICATOR #5: Multi-Instrument Screener**
**Priority:** NICE-TO-HAVE  
**Timeframe:** Daily  
**Location:** Separate panel or table

#### Requirements:

**A. Instrument Universe**
Monitor user-defined instruments (default 5)

**B. Relative Strength Ranking**
- Calculate 24H % change
- Rank from 1 (best) to N (worst)

**C. Volatility Regime Display**
- Show regime classification: L/N/H
- Color code: Yellow/Green/Red

**D. Session Alignment Indicator**
Show optimal trading hours per instrument

**E. Current Opportunity Highlight**
Highlight top 2 performers with NORMAL regime

---

## STAGE 3: SETUP

### **INDICATOR #6: SETUP Metrics Validator**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** Daily (primary) + 4H (CMF)  
**Location:** Separate panel with detailed checklist

#### Requirements:

**A. 8 Binary Criteria Checker**

**1. Trend Strength Calculator**
- Calculate: min((emaSep Ã— 10 + priceDist Ã— 10) + alignmentBonus, 100)
- Thresholds: â‰¥75 BEST, 60-74 GOOD, 40-59 ACCEPTABLE, <40 WEAK

**2. EMA Alignment Validator**
- LONG: Close > EMA(8) > EMA(21) > EMA(55)
- SHORT: inverse
- Binary: âœ… or âŒ

**3. CMF (4H timeframe)**
- Calculate CMF(60) on 4H chart
- Threshold: Â±10
- Display strength: VERY STRONG/STRONG/GOOD/WEAK

**4. Gap Ratio Calculator**
- Formula: Gap / ATR(14)
- Acceptance: 0.5-2.0Ã— (ideal: 0.7-1.5Ã—)

**5. ATR Regime Percentile**
- Accept: P30 â‰¤ ATR â‰¤ P70

**6. Daily Regime Classification**
States: RANGING / WEAK TREND / TRENDING / CALM TREND / BREAKOUT / DEAD QUIET
- RANGING (gap < 0.3Ã—): âŒ REJECT
- DEAD QUIET: âŒ REJECT
- Others: Based on gap ratio, ATR percentile, trend strength

**7. 4H Regime Classification**
- Same as daily
- BOTH Daily and 4H must be non-ranging

**8. Price Position Validator**
- Distance from EMA(8): <1.5Ã— ATR
- For LONG: Close > EMA(55)
- For SHORT: Close < EMA(55)

**B. System Status Display**
- âœ… ACTIVE: Both TRENDING
- âš ï¸ RESTRICTED: One WEAK
- ðŸ”¥ CAUTION: One BREAKOUT
- â¸ï¸ PAUSED: Either RANGING

**C. Master Checklist Display**
Visual grid showing all 8 criteria with âœ… or âŒ
Display "VALID SETUP" when 8/8

**D. Alert System**
Alert when transitioning to valid (8/8)

**E. Invalidation Tracking**
Display Fast EMA and Slow EMA levels

---

### **INDICATOR #7: Quality Tier Display**
**Priority:** NICE-TO-HAVE  
**Timeframe:** Daily  
**Location:** Embedded in SETUP Validator

#### Requirements:

**A. Tier Classification**
- BEST: â‰¥75
- GOOD: 60-74
- ACCEPTABLE: 40-59

**B. Display Format**
Show with color coding

**C. Additional Information**
- Direction: LONG/SHORT
- Invalidation levels

---

## STAGE 4: SIGNAL

### **INDICATOR #8: SIGNAL Unified Decision Panel**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** 1H (Hourly)  
**Location:** Large panel on right side

#### Requirements:

**A. 9 Rejection Candle Criteria**

**1. Wick-to-Body Ratio**
- Requirement: â‰¥2:1
- Prefer: â‰¥3:1
- Display actual ratio

**2. Dominant Wick Direction**
- For LONG: lower_wick > upper_wick
- For SHORT: upper_wick > lower_wick

**3. Body Size Check**
- Requirement: â‰¤40% of range
- Prefer: â‰¤25%

**4. Body Position**
- For LONG: body in upper 60%+
- For SHORT: body in lower 60%+

**5. EMA Touch Validator**
- Wick touches/pierces Daily EMA gap
- Body closes correct side

**6. Structure Reclaim Check**
- For LONG: low = lowest in last 10 candles
- For SHORT: high = highest in last 10 candles

**7. Close Position**
- For LONG: close > previous close
- For SHORT: close < previous close

**8. Price vs EMA**
- For LONG: close > Daily Slow EMA(55)
- For SHORT: close < Daily Slow EMA(55)

**9. Volume Spike Detection**
- Requirement: â‰¥1.2Ã—
- Prefer: â‰¥1.5Ã—
- Display multiplier

**B. 5 Additional Validation Checks**

**1. Correction Duration Timer**
- Classify: EXTENDED (â‰¥12h), HEALTHY (8-12h), ADEQUATE (6-8h), RUSHED (4-6h), TOO RUSHED (<4h)
- Minimum: 6 hours

**2. SETUP Validity Checker**
- Re-verify all 8 criteria still pass
- Display: VALID or INVALIDATED

**3. Time Quality Classifier**
- â­ PRIME: 14:00-17:00
- âœ… GOOD: 08:00-14:00, 17:00-18:00
- âš ï¸ MODERATE: 07:00-08:00, 18:00-22:00
- ðŸ”´ CAUTION: 22:00-02:00
- âŒ AVOID: 02:00-07:00

**4. Volume Quality Assessment**
- STRONG: â‰¥2.0Ã—
- GOOD: 1.5-2.0Ã—
- MODERATE: 1.2-1.5Ã—
- WEAK: <1.2Ã— (reject)

**5. Invalidation Tracker**
Two levels:
- Fast EMA breach: âš ï¸ WARNING
- Slow EMA breach: âŒ INVALIDATED

**C. SIGNAL Decision Display**
- ðŸ”” READY: All pass
- â³ WAIT: In correction
- âŒ NO SIGNAL: Criteria not met
- â¸ï¸ PAUSED: System monitoring

**D. Signal Level Capture**
- Auto-capture close of rejection candle
- Calculate entry zone
- Draw visual zone on chart

---

### **INDICATOR #9: Volume Monitor**
**Priority:** SHOULD-HAVE  
**Timeframe:** 1H  
**Location:** Below SIGNAL panel

#### Requirements:

**A. Volume Ratio Calculator**
- Calculate: current_volume / SMA(volume, 20)
- Display ratio

**B. Quality Tier Display**
Color-coded: STRONG/GOOD/MODERATE/WEAK

**C. Visual Volume Bars**
Plot and color code

**D. Alert System**
Alert at 1.2Ã— and 1.5Ã— thresholds

---

### **INDICATOR #10: Session Tracker (Optional)**
**Priority:** NICE-TO-HAVE  
**Timeframe:** Intraday  
**Location:** Chart overlay

#### Requirements:

**A. Session High/Low Tracking**
Track Japan, Europe, US sessions

**B. Visual Display**
- Draw boxes for each session
- Draw H/L lines
- Color code by session

**C. DST Adjustment**
Auto-adjust times

**D. Usage Context**
- Sweep check
- Stop orientation
- Target orientation

---

## STAGE 5: TRIGGER

### **INDICATOR #11: Trigger Master Detection**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** 5min  
**Location:** Large panel or overlay

#### Requirements:

**A. Signal Level Management**

**Auto-Capture Mode:**
- Detect 1H rejection candle
- Auto-capture signal level
- Start timer
- Set 5-hour timeout

**Manual Override:**
- Allow manual input
- Manual timeout: 5 hours

**Signal Freshness Tracking:**
- Display: "Signal Age: Xh Ym"
- Color coding:
  - Green: <2 hours (fresh)
  - Yellow: 2-4 hours (aging)
  - Red: 4-5 hours (stale)
  - Gray: >5 hours (expired)
- Alert at 4h 30min: "Signal expiring in 30 minutes"
- Auto-invalidate after 5 hours

**B. Entry Zone Calculation**

**Zone Width:**
- Default: 10 pips
- Regime adjustment:
  - LOW/NORMAL: Â±0.5Ã— ATR
  - HIGH: Â±0.75Ã— ATR

**Visual Display:**
- Draw shaded zone on chart
- Green for LONG, Red for SHORT
- Fade as signal ages

**In-Zone Detector:**
- Check if price in zone
- Display distance if outside

**C. 3 Trigger Conditions**

**1. Price in Entry Zone**
Must be in zone âœ…

**2. Quality Pattern Checker**
- Body â‰¥40% of range
- Close position â‰¥50%
- Tiers: EXCELLENT/STRONG/GOOD/WEAK

**3. Volume Confirmation**
- Requirement: â‰¥1.2Ã— SMA(50)

**D. Rejection Strength Percentile (Advisory)**
Calculate percentile vs last 12 candles
- EXCEPTIONAL: P90-P100
- STRONG: P75-P89
- MODERATE: P50-P74
- WEAK: <P50

**E. System Status Integration**
Check system state from SETUP Validator

**F. Trigger Decision Display**
Visual table showing all conditions
Decision: ðŸ”¥ FIRE / â³ WAIT / âŒ NO TRIGGER / â¸ï¸ BLOCKED

**G. Execution Timing Guidance**
Display: "Execute at 4:30-4:50 mark of 5min candle"

---

### **INDICATOR #12: Trigger Volume Ratio**
**Priority:** SHOULD-HAVE  
**Timeframe:** 5min  
**Location:** Below Trigger Master

#### Requirements:

**A. Volume Ratio Calculation**
- Calculate: volume / SMA(volume, 50)
- Update every candle

**B. Real-Time Display**
Large number showing ratio

**C. Color Coding**
Green (â‰¥1.2Ã—), Yellow (1.0-1.2Ã—), Red (<1.0Ã—)

**D. Quality Tier Display**
STRONG/GOOD/MODERATE/WEAK

**E. Volume Bars**
Plot and color code

**F. Alert System**
Alert at 1.2Ã— threshold

---

## STAGE 6: EXIT

### **INDICATOR #13: Exit Management Dashboard**
**Priority:** SHOULD-HAVE  
**Timeframe:** Multi-timeframe  
**Location:** Large panel

#### Requirements:

**A. Target Calculator**
- Base: entry + (stop_distance Ã— R Ã— regime_adj)
- Regime adjustments: LOW 1.3R, NORMAL 1.5-2.0R, HIGH 1.5-2.0R
- Session adjustments: ACCEPTABLE -0.2R, WEAK -0.3R
- Draw target line on chart

**B. Stop Loss Calculator**
- Structure-based with ATR buffer
- Regime adjustments: LOW 0.8Ã—, NORMAL 1.0Ã—, HIGH 1.5Ã—
- Draw stop line on chart

**C. 60-Minute Position Timer (CRITICAL - ENHANCED)**
- **Large, prominent countdown display**
- **Format: "Time in Trade: 35m 20s / 60m"**
- **Progress bar with color coding:**
  - **Green: 0-45 minutes**
  - **Yellow: 45-55 minutes**
  - **Red: 55-60 minutes**
- **Alert at 55 minutes: "âš ï¸ 5 minutes until forced exit"**
- **Alert at 58 minutes: "ðŸš¨ 2 minutes - EXIT NOW"**
- **At 60 minutes: "ðŸ›‘ FORCE EXIT" (overrides all)**

**D. Live R-Multiple Display**
- Calculate: current_R
- Display with P&L in EUR
- Color coded
- Track max R achieved

**E. Emergency Exit Triggers**
Five types:
1. Structure break detector
2. Pattern failure alert
3. News proximity warning
4. Risk limit approaching
5. Technical breakdown

**F. Exit Monitoring Checklist**
Table format for 5-minute checks

**G. Regime-Specific Exit Guidance**
- LOW: Consider early exit at 1.0R
- NORMAL: Hold for full target
- HIGH: Trail stop after 1.0R

---

## CROSS-CUTTING / CRITICAL SAFETY INDICATORS

### **INDICATOR #14: Risk Management Dashboard**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** Real-time  
**Location:** Top-left, always visible

#### Requirements:

**A. Daily P&L Tracker**
- Track all trades (reset at 00:00 CET)
- Running total: closed P&L + open P&L
- Color zones:
  - Green: 0 to -100 EUR
  - Yellow: -100 to -200 EUR
  - Orange: -200 to -280 EUR
  - Red: -280 to -300 EUR
- At -300 EUR: Block all new trades
- Alert sequence: -200, -250, -280, -300 EUR

**B. Position Counter**
- Count open positions
- Display: "Positions: 1 / 2 max"
- Maximum: 2 concurrent (hard limit)
- Show summary for each position

**C. Time Window Validator**
- Trading hours: 09:00-19:00 CET
- Green: 09:00-18:30
- Yellow: 18:30-19:00 (close only)
- Red: Outside hours
- Block entries outside hours

**D. Session Strength Display**
Link to Indicator #4
Display current max position size

**E. Friday Close Warning System (ENHANCED)**
- **Detect Friday automatically**
- **Warning sequence:**
  - **15:30 CET: "âš ï¸ Friday 16:00 close in 30 min"**
  - **15:45 CET: "âš ï¸ 15 minutes to Friday close"**
  - **15:50 CET: "ðŸš¨ 10 minutes - EXIT ALL"**
  - **15:55 CET: "ðŸš¨ 5 MINUTES - FORCE EXIT"**
- **Block entries after 15:30 Friday**
- **Force close at 16:00 CET**
- **Never hold over weekend**

**F. Hard Stop Warnings**
- Major news events
- Weekend approach
- 60-minute position limit

**G. Comprehensive Status Panel**
Single glance view of all risk states
Display "ðŸ›‘ TRADING BLOCKED" if any violation

---

### **INDICATOR #15: Position Size Calculator**
**Priority:** SHOULD-HAVE  
**Timeframe:** Any  
**Location:** Separate panel or popup

#### Requirements:

**A. Input Fields**
- Stop distance
- Risk amount (100/75/50 EUR)
- Auto-fill: regime, correlation, session

**B. Regime Adjustment**
- HIGH regime: Reduce by 50%

**C. Correlation Adjustment**
- Conflict detected: Reduce to 50 EUR per position

**D. Session Adjustment**
- PRIME: Full amount
- ACCEPTABLE: Consider -25%
- WEAK: Force 50 EUR max

**E. Position Size Calculation**
Calculate position size in units/lots

**F. Output Display**
- Position size
- Risk per trade
- Effective leverage

**G. KO Distance Preview**
Show minimum needed (2.0Ã—)

---

### **INDICATOR #16: News Calendar Proximity Alert**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** Real-time  
**Location:** Top banner

#### Requirements:

**A. News Data Source**
- Economic calendar API or manual input
- TradingView calendar integration

**B. Event Classification**
Track HIGH impact only:
- NFP, FOMC, ECB decisions
- GDP releases
- CPI/Inflation data
- Interest rate decisions

**C. Proximity Detection**
Calculate time to next event:
- >60 min: Green (clear)
- 30-60 min: Yellow (warning)
- <30 min: Red (danger)
- Event ongoing: Red (block)

**D. Visual Display**
Status banner: "ðŸ“° NEWS: NFP in 45 minutes"
Color background based on proximity

**E. Countdown Timer**
When <60 minutes:
- Display: "NFP in 23m 45s"
- Update every second

**F. Entry Blocking Logic**
- <30 min: Block ALL entries
- <10 min: Warn to exit
- During event: Block everything
- Set flag: NEWS_BLOCK = true

**G. Alert System**
- 60 min: "ðŸ“° Major news in 60 min"
- 30 min: "âš ï¸ News in 30 min"
- 20 min: "ðŸš¨ NO NEW ENTRIES"
- 10 min: "ðŸš¨ Consider closing positions"

**H. Multi-Event Tracking**
Show next 3 events

**I. Currency-Specific Filtering**
Filter events by relevance to traded pair

---

### **INDICATOR #17: Spread Monitor**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** Real-time  
**Location:** Status bar or in Trigger panel

#### Requirements:

**A. Spread Calculation**
- Calculate: spread = ask - bid
- Convert to pips for forex
- Update every tick

**B. Threshold by Instrument**
- EUR/USD: Max 3 pips
- USD/JPY: Max 4 pips
- GBP/USD: Max 4 pips
- Gold: Max 50 cents
- Silver: Max 5 cents
- Oil: Max 5 cents
- User customizable

**C. Status Classification**
- âœ… NORMAL: â‰¤ normal threshold
- âš ï¸ WIDE: Normal < spread â‰¤ max
- âŒ TOO WIDE: > max (reject trade)

**D. Visual Display**
Format: "Spread: 2.3 pips (NORMAL) âœ…"
Show typical spread for reference

**E. Execution Blocking**
When TOO WIDE:
- Block entry
- Display: "ðŸ›‘ Spread too wide"

**F. Alert System**
Alert on status changes

**G. Historical Context**
- Average spread last 24H
- Maximum spread last 24H
- Current vs average %

**H. Time-Based Patterns**
Note spreads widen during:
- Major news
- Outside main hours
- Friday afternoon
- Rollover times

---

### **INDICATOR #18: KO Distance Validator**
**Priority:** MUST-HAVE (CRITICAL)  
**Timeframe:** Pre-trade  
**Location:** Separate panel or in Position Calculator

#### Requirements:

**A. Distance Calculation**
For LONG:
- KO_distance = Entry - KO_barrier
- Stop_distance = Entry - Stop
- Ratio = KO_distance / Stop_distance

For SHORT: inverse

**B. Ratio Requirements**
- Minimum: 2.0Ã— (MANDATORY)
- Preferred: 2.5Ã—+
- HIGH regime: 2.5Ã— minimum REQUIRED

**C. Visual Display**
Color-coded validation:
- Green: â‰¥2.5Ã— (EXCELLENT)
- Light Green: 2.0-2.5Ã— (ACCEPTABLE)
- Red: <2.0Ã— (REJECT)

Display:
```
Entry: 1.2345
Stop: 1.2300 (45 pips)
KO Barrier: 1.2250
KO Distance: 95 pips
Ratio: 2.11Ã— âœ… SAFE
```

**D. Auto-Calculate Safe Barrier**
Given entry and stop:
- Calculate: safe_KO = entry - (stop_dist Ã— 2.0)
- Display recommendation

**E. Slippage Buffer**
Consider typical slippage:
- Normal: 2-3 pips
- High volatility: 5-10 pips
- News: 10-20+ pips

**F. Regime-Adjusted Recommendations**
- LOW: 2.0Ã— acceptable
- NORMAL: 2.0-2.5Ã— recommended
- HIGH: 2.5Ã— minimum REQUIRED

**G. Real-Time Monitoring**
During trade:
- Track distance to KO
- Display: "KO barrier: 85 pips away"
- Alert if price approaches:
  - "âš ï¸ 30 pips from KO barrier"
  - "ðŸš¨ 15 pips - EXIT NOW"

**H. Pre-Trade Blocking**
If ratio <2.0:
- Set flag: KO_INVALID = true
- Block entry
- Display: "ðŸ›‘ KO distance too small"

---

### **INDICATOR #19: Multi-Timeframe Sync Monitor**
**Priority:** SHOULD-HAVE  
**Timeframe:** Multi  
**Location:** Separate status panel

#### Requirements:

**A. Purpose**
Single-glance view of readiness across timeframes

**B. Timeframe Status Checks**
- **Daily:** SETUP valid? (8/8)
- **4H:** CMF valid? Regime valid?
- **1H:** SIGNAL detected?
- **5min:** TRIGGER ready?

**C. Visual Checklist**
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ MULTI-TIMEFRAME STATUS         â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Daily:  âœ… SETUP (8/8)         â”‚
â”‚         âœ… Regime TRENDING     â”‚
â”‚ 4H:     âœ… CMF +15 (STRONG)    â”‚
â”‚         âœ… Regime TRENDING     â”‚
â”‚ 1H:     âœ… SIGNAL DETECTED     â”‚
â”‚         â° Age: 2h 15m         â”‚
â”‚ 5min:   â³ WAITING IN ZONE     â”‚
â”‚ OVERALL: â³ 3/4 READY          â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**D. Stage-by-Stage Status**
Track Framework 2.0 stages:
1. SCREENING: VIX clear?
2. SETUP: 8/8 pass?
3. SIGNAL: Rejection detected?
4. TRIGGER: In zone with pattern?

**E. Overall GO/NO-GO Status**
- **GO (Green):** All 4 stages âœ…, no blocks
- **WAIT (Yellow):** 3/4 stages ready
- **NO-GO (Red):** <3 stages or critical block

**F. Bottleneck Identification**
Show what's blocking:
- "Waiting on: 1H SIGNAL detection"
- "Blocked by: Daily stop hit"
- "Blocked by: News in 15 min"

**G. Quick Access Links**
Show which criteria failing

**H. Alert on Full Alignment**
When READY: "ðŸš€ ALL SYSTEMS GO - EUR/USD ready"

---

## IMPLEMENTATION NOTES

### **Standard Settings**
```pinescript
// EMAs
ema_fast = 8
ema_mid = 21
ema_slow = 55

// ATR
atr_period = 14
atr_lookback = 100

// Regime Thresholds
regime_ranging = 0.3
regime_weak = 0.5
atr_low = 20
atr_high = 80

// Time Windows (CET)
trading_start = 0900
trading_end = 1900
prime_start = 1430
prime_end = 1730

// Risk Limits
daily_stop = 300  // EUR
max_positions = 2
max_hold_time = 60  // minutes
```

### **Color Scheme**
```pinescript
// System States
color_active = color.green
color_restricted = color.yellow
color_caution = color.orange
color_paused = color.red

// Validation
color_valid = color.new(color.green, 80)
color_invalid = color.new(color.red, 80)

// Regime
color_regime_low = color.yellow
color_regime_normal = color.green
color_regime_high = color.red
```

---

## CRITICAL PATH

**Implement these 8 first for safe live trading:**

1. Risk Management Dashboard (#14)
2. KO Distance Validator (#18)
3. News Calendar Proximity Alert (#16)
4. Spread Monitor (#17)
5. Volatility Regime Monitor (#2)
6. SETUP Metrics Validator (#6)
7. SIGNAL Decision Panel (#8)
8. Trigger Master Detection (#11)

---

**END OF PS_REQUIREMENTS - COMPLETE**
