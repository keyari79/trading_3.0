# PINESCRIPT DEVELOPMENT PRIORITIES FOR FRAMEWORK 2.0
**Purpose:** Optimal scripting order for TradingView indicators  
**Goal:** Automate calculations, let Claude verify decisions

---

## ðŸŽ¯ PRIORITY 1: RISK MANAGEMENT DASHBOARD
**Why First:** Prevents account destruction with 20Ã— leverage

```pinescript
//@version=5
indicator("Framework 2.0 - Risk Dashboard", overlay=true)

// FEATURES NEEDED:
// 1. Daily P&L Tracker
//    - Shows current daily P&L in EUR
//    - Green: 0 to -100
//    - Yellow: -100 to -200  
//    - Red: -200 to -300
//    - BLOCKS NEW TRADES at -300 (visual alert)

// 2. Position Counter
//    - Tracks open positions (max 2)
//    - Warns at 2 positions
//    - Shows position correlation status

// 3. Time Window Validator
//    - Green: 09:00-18:30 CET
//    - Yellow: 18:30-19:00 CET (close only)
//    - Red: Outside trading hours

// 4. Session Strength Display
//    - PRIME (14:30-17:30): "100 EUR"
//    - ACCEPTABLE: "75 EUR"  
//    - WEAK: "50 EUR"

// 5. Hard Stop Warnings
//    - Friday 16:00 warning
//    - Major news countdown
//    - 60-minute position timer
```

**Output:** Visual dashboard showing all risk states at a glance

---

## ðŸŽ¯ PRIORITY 2: VOLATILITY REGIME MONITOR
**Why Second:** Determines position sizing for every trade

```pinescript
//@version=5
indicator("Framework 2.0 - Volatility Regime", overlay=false)

// FEATURES NEEDED:
// 1. ATR Percentile Calculation (20-day lookback)
//    - Calculate current ATR(14)
//    - Compare to 20-day history
//    - Determine percentile rank

// 2. Regime Classification
//    - LOW: <20th percentile â†’ "L" + Yellow background
//    - NORMAL: 20-80th percentile â†’ "N" + Green background
//    - HIGH: >80th percentile â†’ "H" + Red background

// 3. Auto Position Size Display
//    - LOW: "100 EUR / Target 1.3R"
//    - NORMAL: "100 EUR / Target 1.5R"
//    - HIGH: "50 EUR / Target 1.5R"

// 4. Multi-Instrument Panel
//    - Show regime for all 5 instruments
//    - Update every 5 minutes
//    - Alert on regime changes

// 5. Entry Zone Adjustment
//    - Show adjusted entry zone size
//    - LOW/NORMAL: Â±0.5 ATR
//    - HIGH: Â±0.75 ATR
```

**Output:** Clear regime status for position sizing decisions

---

## ðŸŽ¯ PRIORITY 3: SETUP VALIDATOR (15-minute)
**Why Third:** Identifies valid trading opportunities

```pinescript
//@version=5
indicator("Framework 2.0 - SETUP Validator", overlay=true)

// FEATURES NEEDED:
// 1. EMA Alignment Check
//    - Plot EMA 8, 21, 55
//    - Check if properly stacked
//    - âœ“/âœ— indicator

// 2. Gap Ratio Calculator
//    - (EMA8 - EMA21) / EMA21
//    - Must be > 0.1% but < 0.5%
//    - Display actual percentage

// 3. Price Distance from EMA 8
//    - Calculate distance in ATR units
//    - Must be < 1.5 ATR
//    - Show current distance

// 4. Trend Strength Counter
//    - Count consecutive directional candles
//    - Need 3+ for valid trend
//    - Display count

// 5. CMF Volume Confirmation
//    - Plot CMF(21)
//    - Must be >0 for longs, <0 for shorts
//    - Show value

// 6. Master Checklist Display
//    - Shows all 7 criteria
//    - Green âœ“ or Red âœ— for each
//    - "VALID SETUP" when 7/7 pass
//    - Alert when valid setup appears
```

**Output:** Checklist showing which setup criteria are met

---

## ðŸŽ¯ PRIORITY 4: SIGNAL DETECTOR (5-minute)
**Why Fourth:** Identifies rejection candles for entry

```pinescript
//@version=5
indicator("Framework 2.0 - SIGNAL Detector", overlay=true)

// FEATURES NEEDED:
// 1. Rejection Candle Identifier
//    - Calculate wick-to-body ratio
//    - Identify dominant wick direction
//    - Check body size (<40% of range)
//    - Verify body position

// 2. EMA Touch Validator
//    - Did wick touch/pierce EMA 21?
//    - Did body close correct side?
//    - Visual confirmation

// 3. Volume Spike Detector
//    - Compare to 20-period average
//    - Must be â‰¥1.5x average
//    - Display multiplier

// 4. Structure Reclaim Check
//    - Mark recent swing high/low
//    - Check if reclaimed
//    - Visual indicator

// 5. Signal Quality Score
//    - Shows 0-8 score
//    - Highlights when 8/8 achieved
//    - Alert on valid signal
//    - Start 5-minute countdown timer
```

**Output:** Clear signal when rejection criteria met

---

## ðŸŽ¯ PRIORITY 5: CORRELATION MATRIX
**Why Fifth:** Prevents hidden double exposure

```pinescript
//@version=5
indicator("Framework 2.0 - Correlation Matrix", overlay=false)

// FEATURES NEEDED:
// 1. 20-Day Rolling Correlations
//    - EUR/USD â†” USD/JPY
//    - EUR/USD â†” Gold  
//    - Oil â†” USD/JPY
//    - Update every 15 minutes

// 2. Conflict Detection
//    - If |correlation| â‰¥ 0.5
//    - Check position directions
//    - Flag conflicts in red

// 3. Position Size Adjuster
//    - Normal: "100 EUR both"
//    - Conflict: "50 EUR both"
//    - Display recommendation

// 4. Visual Matrix
//    - Color-coded cells
//    - Green: No conflict
//    - Yellow: Watch (0.4-0.5)
//    - Red: Conflict (>0.5)
```

**Output:** Matrix showing correlation status

---

## ðŸŽ¯ PRIORITY 6: ENTRY/EXIT CALCULATOR
**Why Sixth:** Handles math quickly and accurately

```pinescript
//@version=5
indicator("Framework 2.0 - Entry/Exit Calculator", overlay=true)

// FEATURES NEEDED:
// 1. Entry Zone Visualizer
//    - Draw zones Â±0.5 ATR from signal
//    - Adjust for volatility regime
//    - Show time remaining (5 min limit)

// 2. Stop Loss Calculator
//    - Find structure low/high
//    - Add ATR buffer (regime-based)
//    - Display exact level

// 3. Target Calculator
//    - Calculate R-based target
//    - Adjust for regime (1.3R if LOW)
//    - Adjust for session strength
//    - Display exact level

// 4. Position Size Calculator
//    - Input: Stop distance
//    - Input: Risk amount (EUR)
//    - Output: Position size
//    - Output: KO distance needed

// 5. Live R-Multiple Display
//    - Shows current P&L in R
//    - Updates in real-time
//    - Color-coded (green/red)
```

**Output:** All math done automatically

---

## ðŸ“‹ OPTIMAL DEVELOPMENT SCHEDULE

### Week 1: Foundation (MUST HAVE)
```
Day 1-2: Risk Management Dashboard
Day 3-4: Volatility Regime Monitor  
Day 5-7: Test with paper trades using Claude
```

### Week 2: Detection (SHOULD HAVE)
```
Day 8-9: Setup Validator
Day 10-11: Signal Detector
Day 12-14: Integration testing
```

### Week 3: Enhancement (NICE TO HAVE)
```
Day 15-16: Correlation Matrix
Day 17-18: Entry/Exit Calculator
Day 19-21: Full system test
```

---

## ðŸ”§ CODING TIPS

### For All Indicators:
```pinescript
// Standard Settings
defval_lookback = 20  // Regime lookback
defval_atr = 14       // ATR period
defval_ema_fast = 8   // Fast EMA
defval_ema_mid = 21   // Medium EMA
defval_ema_slow = 55  // Slow EMA

// Time Windows
trading_hours = time(timeframe.period, "0900-1900")
prime_session = time(timeframe.period, "1430-1730")
```

### Color Schemes:
```pinescript
color_regime_low = color.yellow
color_regime_normal = color.green
color_regime_high = color.red
color_valid = color.new(color.green, 80)
color_invalid = color.new(color.red, 80)
```

### Alert Templates:
```pinescript
alertcondition(valid_setup, 
    title="Setup Valid", 
    message="{{ticker}} - Valid SETUP detected on 15min")

alertcondition(valid_signal, 
    title="Signal Valid", 
    message="{{ticker}} - Valid SIGNAL on 5min - Check for trigger")
```

---

## ðŸ’¡ INTEGRATION WITH CLAUDE

### Your Workflow Will Be:

1. **Scripts detect conditions** â†’ Alert you
2. **You screenshot the setup** â†’ Send to Claude
3. **Claude verifies all criteria** â†’ Gives binary decision
4. **You execute if approved** â†’ Claude tracks the trade
5. **Exit based on rules** â†’ Claude confirms
6. **Post-trade analysis** â†’ Claude provides feedback

### What Scripts CAN'T Do (Claude Will):
- Make discretionary judgments
- Consider multiple timeframes simultaneously  
- Account for news/fundamental context
- Provide post-trade analysis
- Track mistake patterns
- Suggest improvements

### What Claude CAN'T Do (Scripts Will):
- Monitor continuously
- Alert in real-time
- Calculate instantly
- Display visual zones
- Track multiple instruments
- Update every tick

---

## âœ… THIS COMBINATION IS POWERFUL BECAUSE:

**Scripts + Claude = Best of Both Worlds**

- **Scripts:** Speed, consistency, alerts
- **Claude:** Intelligence, verification, learning
- **Together:** Systematic excellence

**Your Edge:** 
- Never miss setups (scripts watching)
- Never break rules (Claude enforcing)
- Always learning (both analyzing)

---

## ðŸ“Ž RESOURCES TO HELP

### PineScript v5 Documentation:
- [TradingView Pine Script Reference](https://www.tradingview.com/pine-script-reference/v5/)

### Framework Constants to Code:
```
RISK_PER_TRADE = 100  // EUR
RISK_REDUCED = 50     // EUR  
MAX_POSITIONS = 2
DAILY_STOP_LOSS = -300  // EUR
MAX_HOLD_TIME = 60    // minutes
CORRELATION_THRESHOLD = 0.5
```

### Testing Checklist:
- [ ] Each indicator works standalone
- [ ] Alerts fire correctly
- [ ] Calculations match manual
- [ ] Visual display is clear
- [ ] Performance is acceptable

---

## ðŸš€ START HERE:

1. **Today:** Start coding Risk Dashboard
2. **Tomorrow:** Add Volatility Regime Monitor
3. **Day 3:** Test both with Claude assistance
4. **Day 4:** Add Setup Validator
5. **Week 2:** Complete remaining indicators

Remember: Even just the first 2 scripts will dramatically improve your trading!
