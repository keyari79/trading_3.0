# CLAUDE AS YOUR TRADING ASSISTANT - OPTIMAL SETUP
**Purpose:** How to use Claude for real-time Framework 2.0 decision support  
**Method:** Structured prompts with screenshots for binary decisions

---

## ðŸŽ¯ THE OPTIMAL WORKFLOW

### Your Division of Labor

**What You Script in TradingView:**
1. **Indicators** (automate calculations):
   - ATR percentile for volatility regime
   - EMA alignment checker (8, 21, 55)
   - Volume spike detector
   - Correlation matrix display
   - Entry zone markers (Â±0.5 ATR)

2. **Alerts** (don't miss opportunities):
   - Setup alignment (7/7 criteria met)
   - Rejection candle formation
   - Entry zone reached
   - Time limit warnings (50 min elapsed)
   - Risk limit warnings

**What Claude Does for You:**
1. **Binary Decision Verification** (double-check your analysis)
2. **Risk Override Checks** (catch what you might miss)
3. **Position Sizing Calculations** (account for all factors)
4. **Exit Decision Support** (objective third party)
5. **Post-Trade Analysis** (learning loop)

---

## ðŸ“‹ OPTIMAL PROMPT TEMPLATES FOR CLAUDE

### TEMPLATE 1: SETUP VALIDATION (Stage 3)
```
I have a potential SETUP on [INSTRUMENT].
Time: [CURRENT TIME CET]
Direction: [LONG/SHORT]

[ATTACH 15-MINUTE CHART SCREENSHOT]

Please verify all 7 SETUP criteria from Framework 2.0:
1. EMA alignment (8>21>55 for long)
2. Gap ratio between EMAs
3. Price position from EMA 8
4. Trend strength (consecutive candles)
5. Structure intact
6. Volume (CMF reading: [VALUE])
7. Time window valid

Also check:
- Current volatility regime
- Session strength
- Any news in next 30 min
- Daily P&L status: [CURRENT P&L]

BINARY DECISION: Valid setup YES/NO?
```

### TEMPLATE 2: SIGNAL CONFIRMATION (Stage 4)
```
SETUP confirmed, now have potential SIGNAL candle.
Instrument: [INSTRUMENT]
Time: [TIME OF SIGNAL CANDLE]

[ATTACH 5-MINUTE CHART SCREENSHOT]

Signal candle stats:
- Total range: [X] pips
- Body size: [X] pips
- Upper wick: [X] pips
- Lower wick: [X] pips
- Volume: [CURRENT] vs [AVERAGE]
- Close position: [X]% of range

Please verify all 8 SIGNAL criteria:
1. Wick-to-body ratio (â‰¥1.5x)
2. Dominant wick direction correct
3. Small body (â‰¤40% of range)
4. Body position (upper/lower 40%)
5. EMA 21 touch
6. Structure reclaim
7. Close position (>50% for long)
8. Volume spike (â‰¥1.5x average)

Plus 5 validations:
- Setup still valid on 15min
- Time quality good
- No news events
- Spread acceptable: [CURRENT SPREAD]
- Risk rules pass

BINARY DECISION: Valid signal YES/NO?
```

### TEMPLATE 3: TRIGGER & ENTRY (Stage 5)
```
SIGNAL confirmed, watching for TRIGGER.
Current price: [PRICE]
Signal candle high/low: [HIGH]/[LOW]
Current time: [TIME]
Minutes since signal: [X]

[ATTACH 1-MINUTE CHART SCREENSHOT]

1-minute candle forming:
- Body size: [X]% of range
- Close position: [X]%
- Volume vs average: [X]x

Pre-entry checks:
- Volatility regime: [LOW/NORMAL/HIGH]
- Session strength: [PRIME/ACCEPTABLE/WEAK]
- Existing positions: [LIST ANY]
- Correlation conflicts: [YES/NO]
- Current daily P&L: [AMOUNT]

Calculate for me:
1. Am I in valid entry zone (Â±0.5 ATR)?
2. Position size (account for regime/correlation)
3. Stop loss level
4. Target level
5. KO certificate distance needed

BINARY DECISION: Execute trade YES/NO?
```

### TEMPLATE 4: EXIT MANAGEMENT
```
POSITION ACTIVE - Need exit decision.
Entry: [PRICE] at [TIME]
Current: [PRICE] at [TIME]
P&L: [X] EUR ([X]R)
Time in trade: [X] minutes

[ATTACH CURRENT CHART SCREENSHOT]

Current status:
- Target: [PRICE] - distance: [X] pips
- Stop: [PRICE] - distance: [X] pips
- Structure levels intact: [YES/NO]
- News coming: [NONE/TIME]

Please check exit triggers:
1. Any Tier 0 overrides active?
2. Any emergency exits triggered?
3. Approaching 60-minute limit?
4. Should I adjust stop (regime-based)?
5. Should I take early profit (session-based)?

RECOMMENDED ACTION: [HOLD/EXIT/ADJUST]
```

### TEMPLATE 5: POST-TRADE ANALYSIS
```
TRADE COMPLETED - Need analysis.

Trade Details:
- Instrument: [INSTRUMENT]
- Entry: [PRICE] at [TIME]
- Exit: [PRICE] at [TIME]
- P&L: [X] EUR ([X]R)
- Exit reason: [TARGET/STOP/TIME/EMERGENCY]

[ATTACH ENTRY SCREENSHOT]
[ATTACH EXIT SCREENSHOT]

Please analyze:
1. Setup quality score (0-7)
2. Signal quality score (0-8)
3. Trigger quality score (0-3)
4. Execution quality (1-5)
5. Risk compliance (YES/NO)

What went right:
What went wrong:
Mistake category (if any):
Key lesson:
Action for next time:
```

---

## ðŸ”§ SCRIPTING PRIORITIES

### MUST SCRIPT (Saves Time & Reduces Errors):

**Priority 1: Volatility Regime Monitor**
```pinescript
// Shows current regime for all 5 instruments
// Updates every 5 minutes
// Color codes: Green=NORMAL, Yellow=LOW, Red=HIGH
// Displays position size adjustment
```

**Priority 2: Setup Validator (15min)**
```pinescript
// Checks all 7 criteria automatically
// Shows checklist with âœ“/âœ— for each
// Alerts when 7/7 achieved
// Prevents missing setups
```

**Priority 3: Signal Detector (5min)**
```pinescript
// Identifies rejection candles
// Calculates wick ratios
// Checks volume spike
// Alerts on valid signals
```

**Priority 4: Risk Management Dashboard**
```pinescript
// Shows daily P&L
// Tracks position count
// Displays correlation matrix
// Warning at -200 EUR
// BLOCKS trades at -300 EUR
```

### NICE TO SCRIPT (But Claude Can Handle):

- Entry zone visualization
- Target/stop calculators
- Time limit timers
- Exit trigger alerts
- Post-trade metrics

---

## ðŸ’¡ TIPS FOR OPTIMAL CLAUDE ASSISTANCE

### 1. Start Each Trading Session With:
```
"I'm starting a trading session with Framework 2.0.
Current date/time: [DATE TIME CET]
Daily P&L starting: [AMOUNT]
Please load Framework 2.0 rules and confirm ready to assist."
```

### 2. Always Include in Screenshots:
- All indicators (EMAs, ATR, Volume)
- Time and price scales clearly visible
- Current candle highlighted
- Any drawn levels or zones

### 3. Be Specific About Context:
- Current volatility regime
- Session time (for strength)
- Existing positions
- Daily P&L status
- Any unusual conditions

### 4. Use Claude for Second Opinion:
- "I think this is valid, please confirm"
- "I want to exit early, is this justified?"
- "I'm seeing X, does this override the signal?"

### 5. End Each Session With:
```
"Session complete. 
Trades taken: [NUMBER]
Final P&L: [AMOUNT]
Please summarize key lessons and mistakes to avoid tomorrow."
```

---

## ðŸ“Š WHAT THIS APPROACH GIVES YOU

### Advantages of Claude + Scripts:

1. **Double Verification** - Scripts catch signals, Claude verifies
2. **Emotion Removal** - Claude doesn't feel FOMO or fear
3. **Rule Enforcement** - Claude won't let you break rules
4. **Learning Loop** - Claude provides consistent analysis
5. **Time Efficiency** - Scripts handle calculations, Claude handles decisions

### Risk Mitigation:

- Scripts prevent missed opportunities
- Claude prevents rule violations
- Combined = maximum safety with 20Ã— leverage

### Continuous Improvement:

- Every trade gets documented analysis
- Patterns emerge over time
- Claude remembers your common mistakes
- System gets refined based on data

---

## ðŸŽ¯ QUICK START GUIDE

### Week 1: Setup Phase
1. **Script the Priority 1 indicators**
2. **Test Claude with paper trades**
3. **Refine prompt templates**
4. **Build screenshot habits**

### Week 2: Integration Phase
1. **Add Priority 2-3 scripts**
2. **Practice full workflow**
3. **Time each interaction**
4. **Optimize for speed**

### Week 3+: Execution Phase
1. **Go live with small size**
2. **Use Claude for every decision**
3. **Document all trades**
4. **Weekly review with Claude**

---

## âš ï¸ IMPORTANT REMINDERS

### Claude's Limitations:
- Can't see real-time prices (need screenshots)
- Can't place trades (you execute)
- Can't predict future (only verify rules)
- May have slight delay (not for HFT)

### Your Responsibilities:
- Provide accurate data
- Take clear screenshots
- Execute trades yourself
- Make final decisions
- Own the results

### Best Practices:
- Pre-write templates for speed
- Keep Framework doc in Claude's context
- Update Claude on P&L status regularly
- Use for verification, not prediction
- Trust the process, not emotions

---

## ðŸš€ SAMPLE TRADING SESSION

### 09:00 - Session Start
```
YOU: "Starting session, P&L at 0"
CLAUDE: "Framework loaded, ready to assist"
```

### 09:15 - Potential Setup
```
YOU: [Template 1 with screenshot]
CLAUDE: "6/7 criteria pass, missing trend strength, NO TRADE"
```

### 10:30 - Valid Setup
```
YOU: [Template 1 with screenshot]
CLAUDE: "7/7 criteria PASS, watch for signal on 5min"
```

### 10:42 - Signal Appears
```
YOU: [Template 2 with screenshot]
CLAUDE: "8/8 criteria PASS, valid signal, watch for trigger"
```

### 10:44 - Trigger & Entry
```
YOU: [Template 3 with screenshot]
CLAUDE: "All conditions met, position size 100 EUR, stop at X, target at Y, EXECUTE"
```

### 11:30 - Exit Decision
```
YOU: [Template 4 with screenshot]
CLAUDE: "Target hit, exit immediately per Tier 1 rules"
```

### 11:33 - Post-Trade
```
YOU: [Template 5 with details]
CLAUDE: "Excellent execution, all rules followed, +1.5R earned"
```

### 19:00 - Session End
```
YOU: "Session complete, 2 trades, +2.3R"
CLAUDE: "Good discipline, avoided 3 marginal setups correctly"
```

---

## âœ… THIS APPROACH IS OPTIMAL BECAUSE:

1. **Leverages strengths of both tools:**
   - Scripts = Speed and calculation
   - Claude = Judgment and verification

2. **Maintains framework discipline:**
   - No emotional overrides
   - Binary decisions enforced
   - Risk rules never broken

3. **Creates feedback loop:**
   - Every trade analyzed
   - Patterns identified
   - Continuous improvement

4. **Scalable and sustainable:**
   - Templates make it fast
   - Scripts reduce workload
   - Claude ensures consistency

---

## YOUR NEXT STEPS:

1. **Save these templates** for easy copy/paste
2. **Start scripting Priority 1** indicators
3. **Practice with paper trades** using Claude
4. **Refine the workflow** for your style
5. **Go live when comfortable** with process

This approach will give you the best of both worlds - automated detection with intelligent verification!
